default_app_config = 'adminpanel.apps.AdminpanelConfig'
