from django.db import models

# The adminpanel app doesn't have its own models.
# It uses models from other apps (users, exams, etc.)
