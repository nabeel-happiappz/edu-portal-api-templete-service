from django.contrib import admin

# The adminpanel app doesn't have any models to register with the admin site.
# Admin functionality is provided through the admin views.
